function setup_provincias(){
	
	// 
	$('#wc-tab a').click(function (e) {
	    e.preventDefault();
	    $(this).tab('show');
    })

	$('#wc-tab a:first').tab('show');
}
