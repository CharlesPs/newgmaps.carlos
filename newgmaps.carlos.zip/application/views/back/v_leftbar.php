                <div class="span3 column-sidebar">
                    <div class="well sidebar-nav">
                        <button class="btn-block toggle-sidebar btn-inverse">
                            <span class="on-span1">
                                <i class="icon-chevron-right icon-white"></i>
                                <i class="icon-chevron-right icon-white"></i>
                            </span>
                            <span class="on-span3">
                                <i class="icon-chevron-left icon-white"></i>
                                <i class="icon-chevron-left icon-white"></i>
                            </span>
                        </button>
                        <ul class="nav nav-list" data-active="<?php echo $left_active; ?>">
                            <li class="nav-header">Sidebar</li>
                            <li><a href="admin/home">Inicio</a></li>
                            <li><a href="admin/provincias">Provincias</a></li>
                            <li><a href="admin/distritos">Distritos</a></li>
                        </ul>
                    </div><!--/.well -->
                </div><!--/span-->
                
