
<footer>
    <div class="container">
        <p class="muted credit">
            Aplicación creada por <a href="http://apfeldor.com">Apfeldor</a> con colaboración de  
            <a href="https://plus.google.com/u/0/112602053945221350415/" target="_blank">
            	Carlos Aguinaga N.
            </a>.
        </p>
    </div>
</footer>
