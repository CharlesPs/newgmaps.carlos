    <div class="container content-control">

      <form class="form-signin">
        <h2 class="form-signin-heading">Inicie Sesión</h2>
        <input id="admin-mail" type="text" class="input-block-level" placeholder="Email" required>
        <input id="admin-pass" type="password" class="input-block-level" placeholder="Contraseña" required>
        <label class="checkbox">
          <input id="admin-save" type="checkbox" value="remember-me"> Recordarme
        </label>
        <button class="btn btn-large btn-primary" type="submit">Ingresar</button>
      </form>

    </div> <!-- /container -->
