
        <div class="container-fluid content-provincias">

            <div class="row-fluid">
                <?php echo $web_leftbar; ?>
                
                <div class="span9 column-hero">
                    <div class="page-header">
                        <h1><?php echo $row->nombre; ?> <small></small></h1>
                    </div>
                    <ul class="breadcrumb">
                        <li><a href="admin">Home</a> <span class="divider">/</span></li>
                        <li><a href="admin/provincias">Provincias</a> <span class="divider">/</span></li>
                        <li class="active"><?php echo $row->nombre; ?></li>
                    </ul>

                    <div class="row-fluid">
                        <ul class="nav nav-tabs" id="wc-tab">
                            <li class="active"><a href="#tab1">Información</a></li>
                            <li><a href="#tab2">Distritos</a></li>
                        </ul>

                        <div class="tab-content">
                            <div class="tab-pane active" id="tab1">
                                tab1
                            </div>
                            <div class="tab-pane" id="tab2">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="20"><input type="checkbox" class="check-select-all"></th>
                                            <th>Nombre</th>
                                            <th width="80">Color</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
foreach($distritos as $row){

    $color = strlen($row->color) == 6 ? "#". $row->color : $row->color;
?>
                                        <tr>
                                            <td><input type="checkbox" id="<?php echo $row->entry; ?>"></td>
                                            <td><?php echo $row->nombre; ?></td>
                                            <td><span class="color-preview" style="background-color: <?php echo $color; ?>">&nbsp;</span></td>
                                            <td>
                                                <a href="admin/distritos/view/<?php echo $row->entry; ?>" class="btn">
                                                    <i class="icon-eye-open"></i> Ver
                                                </a>
                                                <a href="admin/distritos/delete/<?php echo $row->entry; ?>" class="btn btn-danger">
                                                    <i class="icon-trash icon-white"></i> Eliminar
                                                </a>
                                            </td>
                                        </tr>
<?php
}
?>                                    
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <hr>
        </div> <!-- /container -->
